@echo off
cd /d "%~dp0"
set THREADS=%1
set SEATS=%2
set TRAIN=%3
if "%THREADS%"=="" set THREADS=100000
if "%SEATS%"=="" set SEATS=4
if "%TRAIN%"=="" set TRAIN=ALL

if not exist "thread_race.exe" (
    echo [*] Compiling thread_race.c...
    gcc -Wall -Wextra -O2 thread_race.c -o thread_race.exe -lpsapi
)

thread_race.exe %THREADS% %SEATS% %TRAIN%
echo.
pause
