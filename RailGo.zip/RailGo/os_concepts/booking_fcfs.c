#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <ctype.h>
#include <time.h>
#include <windows.h>

#define MAX_PAX 64

typedef struct {
    int index;               /* 1-based index (arrival order) */
    char name[128];
    int age;
    char gender[16];
    char berth_pref[32];
    char quota[64];          /* Emergency, Railway, Handicapped, Student, Tatkal Premium, General */
    int priority;            /* 1 = Highest (Emergency), 2 = Railway, 3 = Handicapped, 4 = Student, 5 = Tatkal Premium, 6 = General */
    DWORD tid;               /* OS Thread ID */
    DWORD pid;               /* Assigned Process ID */
    char status[32];         /* "CNF" or "WL" */
    char coach[32];          /* "S1", "S2", "B1", "WL" */
    char berth_no[32];       /* "12", "WL #1", etc. */
    int burst_time_ms;
} PassengerThreadData;

static HANDLE g_hConsole;

static void set_color(WORD color) {
    if (g_hConsole != NULL && g_hConsole != INVALID_HANDLE_VALUE) {
        SetConsoleTextAttribute(g_hConsole, color);
    }
}

static void reset_color(void) {
    set_color(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
}

/* Helper for case-insensitive substring matching */
static bool contains_ignore_case(const char *haystack, const char *needle) {
    if (!haystack || !needle) return false;
    char h[128], n[128];
    strncpy(h, haystack, sizeof(h) - 1); h[sizeof(h) - 1] = '\0';
    strncpy(n, needle, sizeof(n) - 1); n[sizeof(n) - 1] = '\0';
    for (char *p = h; *p; p++) *p = (char)tolower((unsigned char)*p);
    for (char *p = n; *p; p++) *p = (char)tolower((unsigned char)*p);
    return strstr(h, n) != NULL;
}

/* Map quota names to Priority Levels (1 to 6) */
static int get_quota_priority(const char *q) {
    if (!q || strlen(q) == 0) return 6;
    if (contains_ignore_case(q, "EMERGENCY") || contains_ignore_case(q, "EMG")) return 1;
    if (contains_ignore_case(q, "RAILWAY") || contains_ignore_case(q, "RLW"))   return 2;
    if (contains_ignore_case(q, "HANDICAP") || contains_ignore_case(q, "DIVYAANG") || contains_ignore_case(q, "HP") || contains_ignore_case(q, "PH")) return 3;
    if (contains_ignore_case(q, "STUDENT") || contains_ignore_case(q, "STU"))   return 4;
    if (contains_ignore_case(q, "TATKAL") || contains_ignore_case(q, "PREMIUM") || contains_ignore_case(q, "PT") || contains_ignore_case(q, "TQ")) return 5;
    return 6; /* General Quota */
}

static const char* get_quota_label(int priority) {
    switch (priority) {
        case 1: return "Emergency Quota";
        case 2: return "Railway Quota";
        case 3: return "Handicapped Quota";
        case 4: return "Student Quota";
        case 5: return "Tatkal Premium";
        default: return "General Quota";
    }
}

static const char* get_priority_tag(int priority) {
    switch (priority) {
        case 1: return "P1 (Highest)";
        case 2: return "P2 (High)";
        case 3: return "P3 (Med-High)";
        case 4: return "P4 (Medium)";
        case 5: return "P5 (Normal)";
        default: return "P6 (Standard)";
    }
}

/* Worker thread function */
static DWORD WINAPI PassengerThreadWorker(LPVOID lpParam) {
    PassengerThreadData *data = (PassengerThreadData *)lpParam;
    data->tid = GetCurrentThreadId();
    Sleep((DWORD)data->burst_time_ms);
    return 0;
}

int main(int argc, char *argv[]) {
    g_hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTitleA("RailGo OS Engine - Multi-Threaded Priority CPU Scheduler");

    char in_file_path[MAX_PATH] = {0};
    char out_file_path[MAX_PATH] = {0};

    if (argc >= 3) {
        strncpy(in_file_path, argv[1], sizeof(in_file_path) - 1);
        strncpy(out_file_path, argv[2], sizeof(out_file_path) - 1);
    } else {
        printf("[ERROR] Missing arguments. Usage: booking_fcfs.exe <inputFile> <outputFile>\n");
        return 1;
    }

    FILE *fin = fopen(in_file_path, "r");
    if (!fin) {
        fprintf(stderr, "[ERROR] Could not open input file: %s\n", in_file_path);
        return 1;
    }

    char pnr[32] = "1000000000";
    char train_no[32] = "12017";
    char train_name[128] = "Express Special";
    char journey_date[32] = "2026-11-20";
    char from_stn[32] = "NDLS";
    char to_stn[32] = "DDN";
    char class_code[16] = "SL";
    int available_seats = 4;
    int pax_count = 0;

    PassengerThreadData passengers[MAX_PAX];
    memset(passengers, 0, sizeof(passengers));

    char line[512];
    while (fgets(line, sizeof(line), fin)) {
        char *nl = strchr(line, '\r'); if (nl) *nl = '\0';
        nl = strchr(line, '\n'); if (nl) *nl = '\0';
        if (strlen(line) == 0) continue;

        if (strncmp(line, "PNR:", 4) == 0) {
            strncpy(pnr, line + 4 + (line[4] == ' '), sizeof(pnr) - 1);
        } else if (strncmp(line, "TRAIN_NO:", 9) == 0) {
            strncpy(train_no, line + 9 + (line[9] == ' '), sizeof(train_no) - 1);
        } else if (strncmp(line, "TRAIN_NAME:", 11) == 0) {
            strncpy(train_name, line + 11 + (line[11] == ' '), sizeof(train_name) - 1);
        } else if (strncmp(line, "DATE:", 5) == 0) {
            strncpy(journey_date, line + 5 + (line[5] == ' '), sizeof(journey_date) - 1);
        } else if (strncmp(line, "FROM:", 5) == 0) {
            strncpy(from_stn, line + 5 + (line[5] == ' '), sizeof(from_stn) - 1);
        } else if (strncmp(line, "TO:", 3) == 0) {
            strncpy(to_stn, line + 3 + (line[3] == ' '), sizeof(to_stn) - 1);
        } else if (strncmp(line, "CLASS:", 6) == 0) {
            strncpy(class_code, line + 6 + (line[6] == ' '), sizeof(class_code) - 1);
        } else if (strncmp(line, "AVAILABLE_SEATS:", 16) == 0) {
            available_seats = atoi(line + 16 + (line[16] == ' '));
        } else if (strncmp(line, "PASSENGER:", 10) == 0) {
            if (pax_count < MAX_PAX) {
                char *payload = line + 10 + (line[10] == ' ');
                /* Format: name|age|gender|berth|quota */
                char name[128] = "Passenger";
                int age = 25;
                char gender[16] = "M";
                char berth[32] = "NP";
                char quota[64] = "General Quota";

                char *token = strtok(payload, "|");
                if (token) strncpy(name, token, sizeof(name) - 1);
                token = strtok(NULL, "|");
                if (token) age = atoi(token);
                token = strtok(NULL, "|");
                if (token) strncpy(gender, token, sizeof(gender) - 1);
                token = strtok(NULL, "|");
                if (token) strncpy(berth, token, sizeof(berth) - 1);
                token = strtok(NULL, "|");
                if (token && strlen(token) > 0) {
                    strncpy(quota, token, sizeof(quota) - 1);
                }

                passengers[pax_count].index = pax_count + 1;
                strncpy(passengers[pax_count].name, name, sizeof(passengers[pax_count].name) - 1);
                passengers[pax_count].age = age;
                strncpy(passengers[pax_count].gender, gender, sizeof(passengers[pax_count].gender) - 1);
                strncpy(passengers[pax_count].berth_pref, berth, sizeof(passengers[pax_count].berth_pref) - 1);

                int prio = get_quota_priority(quota);
                passengers[pax_count].priority = prio;
                strncpy(passengers[pax_count].quota, get_quota_label(prio), sizeof(passengers[pax_count].quota) - 1);

                passengers[pax_count].burst_time_ms = 40 + (pax_count * 15);
                pax_count++;
            }
        }
    }
    fclose(fin);

    if (pax_count == 0) {
        passengers[0].index = 1;
        strncpy(passengers[0].name, "Primary Passenger", sizeof(passengers[0].name) - 1);
        passengers[0].age = 28;
        strcpy(passengers[0].gender, "M");
        strcpy(passengers[0].berth_pref, "NP");
        strcpy(passengers[0].quota, "General Quota");
        passengers[0].priority = 6;
        pax_count = 1;
    }

    DWORD host_pid = GetCurrentProcessId();

    /* Terminal banner */
    set_color(FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
    printf("\n");
    printf("========================================================================================\n");
    printf("       IRCTC / RailGo OS ENGINE - MULTI-THREADED PRIORITY CPU SCHEDULER                \n");
    printf("       Process Management, Windows Kernel Threads & Priority Scheduling Algorithm       \n");
    printf("========================================================================================\n");
    reset_color();

    printf("  Train        : %s - %s\n", train_no, train_name);
    printf("  Route        : %s -> %s  | Date: %s | Class: %s\n", from_stn, to_stn, journey_date, class_code);
    printf("  PNR / Job    : %s        | Host Process PID: %lu\n", pnr, (unsigned long)host_pid);

    set_color(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);
    printf("  Inventory    : %d Available Seat(s) vs %d Passenger Contending Request(s)\n", available_seats, pax_count);
    printf("  Priority Hierarchy : Emergency (P1) > Railway (P2) > Handicapped (P3) > Student (P4) > Tatkal Premium (P5) > General (P6)\n");
    reset_color();
    printf("----------------------------------------------------------------------------------------\n\n");

    /* STEP 1: Process Management & OS Thread Creation in exact arrival order */
    set_color(FOREGROUND_GREEN | FOREGROUND_INTENSITY);
    printf("[STEP 1/3] Process Management: Creating OS Threads for Each Passenger...\n");
    reset_color();
    printf("  Assigning OS Process ID (PID) & Thread ID (TID) in EXACT arrival order:\n\n");

    HANDLE thread_handles[MAX_PAX];

    for (int i = 0; i < pax_count; i++) {
        passengers[i].pid = host_pid + (DWORD)i;

        DWORD tid = 0;
        thread_handles[i] = CreateThread(NULL, 0, PassengerThreadWorker, &passengers[i], 0, &tid);
        if (thread_handles[i] != NULL) {
            passengers[i].tid = tid;
        } else {
            passengers[i].tid = 1000 + (DWORD)i;
        }

        set_color(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
        printf("  Thread #%d Spawned ", i + 1);
        reset_color();
        printf("-> [PID: %-5lu | TID: %-5lu] %-18s | Quota: %-19s | Priority: %s\n",
               (unsigned long)passengers[i].pid,
               (unsigned long)passengers[i].tid,
               passengers[i].name,
               passengers[i].quota,
               get_priority_tag(passengers[i].priority));

        Sleep(80);
    }

    /* Wait for worker threads */
    WaitForMultipleObjects((DWORD)pax_count, thread_handles, TRUE, 3000);
    for (int i = 0; i < pax_count; i++) {
        if (thread_handles[i]) CloseHandle(thread_handles[i]);
    }

    printf("\n");

    /* STEP 2: Priority Scheduling Algorithm */
    set_color(FOREGROUND_GREEN | FOREGROUND_INTENSITY);
    printf("[STEP 2/3] Executing OS Priority Scheduling Algorithm...\n");
    reset_color();
    printf("  Evaluating Priority Queue: High priority quota threads preempt lower priority threads.\n");
    printf("  Equal priority requests are resolved using FCFS arrival order:\n\n");

    int priority_queue[MAX_PAX];
    for (int i = 0; i < pax_count; i++) priority_queue[i] = i;

    /* Sort by priority ASC (1=highest), break ties with index ASC (arrival order) */
    for (int i = 0; i < pax_count - 1; i++) {
        for (int j = 0; j < pax_count - i - 1; j++) {
            int idxA = priority_queue[j];
            int idxB = priority_queue[j + 1];
            if (passengers[idxA].priority > passengers[idxB].priority ||
               (passengers[idxA].priority == passengers[idxB].priority && passengers[idxA].index > passengers[idxB].index)) {
                int tmp = priority_queue[j];
                priority_queue[j] = priority_queue[j + 1];
                priority_queue[j + 1] = tmp;
            }
        }
    }

    const char *coach_prefix = "S1";
    if (strstr(class_code, "3A") || strstr(class_code, "2A") || strstr(class_code, "1A")) {
        coach_prefix = "B1";
    } else if (strstr(class_code, "CC") || strstr(class_code, "EC")) {
        coach_prefix = "C1";
    }

    int remaining = available_seats;
    int confirmed_count = 0;
    int waitlist_count = 0;

    for (int q = 0; q < pax_count; q++) {
        int idx = priority_queue[q];
        Sleep(100);

        if (remaining > 0) {
            remaining--;
            confirmed_count++;
            strcpy(passengers[idx].status, "CNF");
            snprintf(passengers[idx].coach, sizeof(passengers[idx].coach), "%s", coach_prefix);
            snprintf(passengers[idx].berth_no, sizeof(passengers[idx].berth_no), "%d", 12 + (confirmed_count * 3));

            set_color(FOREGROUND_GREEN | FOREGROUND_INTENSITY);
            printf("  [Priority Dispatch #%d | %s] PID %lu (%s) -> ",
                   q + 1, get_priority_tag(passengers[idx].priority),
                   (unsigned long)passengers[idx].pid, passengers[idx].name);
            printf("SEAT ALLOCATED: CONFIRMED (CNF) [Coach %s / Berth %s]\n",
                   passengers[idx].coach, passengers[idx].berth_no);
            reset_color();
        } else {
            waitlist_count++;
            strcpy(passengers[idx].status, "WL");
            strcpy(passengers[idx].coach, "WL");
            snprintf(passengers[idx].berth_no, sizeof(passengers[idx].berth_no), "WL #%d", waitlist_count);

            set_color(FOREGROUND_RED | FOREGROUND_INTENSITY);
            printf("  [Priority Dispatch #%d | %s] PID %lu (%s) -> ",
                   q + 1, get_priority_tag(passengers[idx].priority),
                   (unsigned long)passengers[idx].pid, passengers[idx].name);
            printf("SEATS FULL! STATUS: WAITING LIST (WL #%d)\n", waitlist_count);
            reset_color();
        }
    }

    printf("\n");

    /* STEP 3: Summary Table */
    set_color(FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY);
    printf("[STEP 3/3] Final Priority Allocation Summary & Ticket ID Generation:\n");
    printf("========================================================================================\n");
    printf(" # | Passenger Name      | Quota / Category      | Priority | PID   | Coach/Berth | Status      \n");
    printf("----------------------------------------------------------------------------------------\n");
    reset_color();

    for (int i = 0; i < pax_count; i++) {
        char cb_buf[32];
        if (strcmp(passengers[i].status, "CNF") == 0) {
            snprintf(cb_buf, sizeof(cb_buf), "%s / %s", passengers[i].coach, passengers[i].berth_no);
        } else {
            snprintf(cb_buf, sizeof(cb_buf), "%s", passengers[i].berth_no);
        }

        printf(" %d | %-19s | %-21s | %-8s | %-5lu | %-11s | ",
               i + 1,
               passengers[i].name,
               passengers[i].quota,
               get_priority_tag(passengers[i].priority),
               (unsigned long)passengers[i].pid,
               cb_buf);

        if (strcmp(passengers[i].status, "CNF") == 0) {
            set_color(FOREGROUND_GREEN | FOREGROUND_INTENSITY);
            printf("CONFIRMED (CNF)\n");
            reset_color();
        } else {
            set_color(FOREGROUND_RED | FOREGROUND_INTENSITY);
            printf("WAITING LIST (WL)\n");
            reset_color();
        }
    }
    printf("========================================================================================\n");

    DWORD ticket_pid = passengers[0].pid;

    if (waitlist_count == 0) {
        set_color(FOREGROUND_GREEN | FOREGROUND_INTENSITY);
        printf("  >>> SUCCESS: All %d passenger threads confirmed under Priority Scheduling!\n", confirmed_count);
        printf("  >>> TICKET ID (Primary PID): %lu\n", (unsigned long)ticket_pid);
        reset_color();
    } else {
        set_color(FOREGROUND_RED | FOREGROUND_INTENSITY);
        printf("  >>> NOTICE: Available seats (%d) were fewer than requested (%d)!\n", available_seats, pax_count);
        printf("  >>> High priority quota threads (%d) got CNF seats; remaining (%d) placed on WAITING LIST in red.\n",
               confirmed_count, waitlist_count);
        printf("  >>> TICKET ID (Primary PID): %lu\n", (unsigned long)ticket_pid);
        reset_color();
    }

    set_color(FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);
    printf("\n  >>> Closing OS terminal in 2.5 seconds & generating E-Ticket in browser...\n");
    reset_color();

    /* Write JSON output file */
    FILE *fout = fopen(out_file_path, "w");
    if (fout) {
        fprintf(fout, "{\n");
        fprintf(fout, "  \"success\": true,\n");
        fprintf(fout, "  \"ticket_pid\": %lu,\n", (unsigned long)ticket_pid);
        fprintf(fout, "  \"pnr\": \"%s\",\n", pnr);
        fprintf(fout, "  \"confirmed_count\": %d,\n", confirmed_count);
        fprintf(fout, "  \"waitlisted_count\": %d,\n", waitlist_count);
        fprintf(fout, "  \"overall_status\": \"%s\",\n",
                (waitlist_count == 0 ? "CNF" : (confirmed_count > 0 ? "PARTIAL_CNF" : "WL")));
        fprintf(fout, "  \"passengers\": [\n");
        for (int i = 0; i < pax_count; i++) {
            fprintf(fout, "    {\n");
            fprintf(fout, "      \"index\": %d,\n", passengers[i].index);
            fprintf(fout, "      \"name\": \"%s\",\n", passengers[i].name);
            fprintf(fout, "      \"age\": %d,\n", passengers[i].age);
            fprintf(fout, "      \"gender\": \"%s\",\n", passengers[i].gender);
            fprintf(fout, "      \"berth_pref\": \"%s\",\n", passengers[i].berth_pref);
            fprintf(fout, "      \"quota\": \"%s\",\n", passengers[i].quota);
            fprintf(fout, "      \"priority\": %d,\n", passengers[i].priority);
            fprintf(fout, "      \"pid\": %lu,\n", (unsigned long)passengers[i].pid);
            fprintf(fout, "      \"tid\": %lu,\n", (unsigned long)passengers[i].tid);
            fprintf(fout, "      \"status\": \"%s\",\n", passengers[i].status);
            fprintf(fout, "      \"coach\": \"%s\",\n", passengers[i].coach);
            fprintf(fout, "      \"berth_no\": \"%s\"\n", passengers[i].berth_no);
            fprintf(fout, "    }%s\n", (i < pax_count - 1 ? "," : ""));
        }
        fprintf(fout, "  ]\n");
        fprintf(fout, "}\n");
        fclose(fout);
    }

    Sleep(2500);
    return 0;
}
