@echo off
setlocal EnableDelayedExpansion
title RailGo - Operating System Concepts Suite
chcp 65001 >nul
cd /d "%~dp0"

:CHECK_COMPILER
where gcc >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [!] WARNING: GCC compiler not found in PATH.
    echo     Will attempt to run pre-compiled .exe binaries if present.
) else (
    if not exist "1_fcfs_scheduling.exe" set NEED_BUILD=1
    if not exist "2_process_management.exe" set NEED_BUILD=1
    if not exist "3_deadlock_simulation.exe" set NEED_BUILD=1
    if not exist "4_process_synchronization_windows_short.exe" set NEED_BUILD=1
    if not exist "thread_race.exe" set NEED_BUILD=1

    if defined NEED_BUILD (
        echo [*] Compiling OS simulation C programs with GCC...
        gcc -Wall -Wextra -O2 1_fcfs_scheduling.c -o 1_fcfs_scheduling.exe
        gcc -Wall -Wextra -O2 2_process_management.c -o 2_process_management.exe
        gcc -Wall -Wextra -O2 3_deadlock_simulation.c -o 3_deadlock_simulation.exe
        gcc -Wall -Wextra -O2 4_process_synchronization_windows_short.c -o 4_process_synchronization_windows_short.exe
        gcc -Wall -Wextra -O2 thread_race.c -o thread_race.exe -lpsapi
        echo [*] Build complete!
        timeout /t 1 >nul
    )
)

:MENU
cls
echo ======================================================================
echo     RAILGO - OPERATING SYSTEM CONCEPTS SUITE
echo ======================================================================
echo   [1] FCFS Scheduling (Gantt Chart, AT, BT, CT, TAT, WT)
echo   [2] Process Management (5-State Lifecycle, PCB, Context Switch)
echo   [3] Deadlock Simulation (Circular Wait, Banker's Algorithm)
echo   [4] Process Synchronization (Race Condition Bug vs. Mutex Lock)
echo   [5] Heavy OS Thread Race (1,00,000 Threads vs 4 Seats -> CPU Spike)
echo   [6] Recompile All C Programs
echo   [0] Exit
echo ======================================================================
set /p CHOICE="Enter your choice [0-6]: "

if "%CHOICE%"=="1" goto RUN_FCFS
if "%CHOICE%"=="2" goto RUN_PROC
if "%CHOICE%"=="3" goto RUN_DEADLOCK
if "%CHOICE%"=="4" goto RUN_SYNC
if "%CHOICE%"=="5" goto RUN_RACE
if "%CHOICE%"=="6" goto REBUILD
if "%CHOICE%"=="0" goto EXIT_SCRIPT

echo.
echo [!] Invalid selection. Please enter a number between 0 and 6.
timeout /t 2 >nul
goto MENU

:RUN_FCFS
cls
if not exist "1_fcfs_scheduling.exe" gcc -Wall -Wextra -O2 1_fcfs_scheduling.c -o 1_fcfs_scheduling.exe
"1_fcfs_scheduling.exe"
goto MENU

:RUN_PROC
cls
if not exist "2_process_management.exe" gcc -Wall -Wextra -O2 2_process_management.c -o 2_process_management.exe
"2_process_management.exe"
goto MENU

:RUN_DEADLOCK
cls
if not exist "3_deadlock_simulation.exe" gcc -Wall -Wextra -O2 3_deadlock_simulation.c -o 3_deadlock_simulation.exe
"3_deadlock_simulation.exe"
goto MENU

:RUN_SYNC
cls
if not exist "4_process_synchronization_windows_short.exe" gcc -Wall -Wextra -O2 4_process_synchronization_windows_short.c -o 4_process_synchronization_windows_short.exe
"4_process_synchronization_windows_short.exe"
goto MENU

:RUN_RACE
cls
if not exist "thread_race.exe" gcc -Wall -Wextra -O2 thread_race.c -o thread_race.exe -lpsapi
"thread_race.exe" 100000 4 ALL
echo.
pause
goto MENU

:REBUILD
cls
echo [*] Recompiling all C source files with GCC...
gcc -Wall -Wextra -O2 1_fcfs_scheduling.c -o 1_fcfs_scheduling.exe
gcc -Wall -Wextra -O2 2_process_management.c -o 2_process_management.exe
gcc -Wall -Wextra -O2 3_deadlock_simulation.c -o 3_deadlock_simulation.exe
gcc -Wall -Wextra -O2 4_process_synchronization_windows_short.c -o 4_process_synchronization_windows_short.exe
gcc -Wall -Wextra -O2 thread_race.c -o thread_race.exe -lpsapi
echo.
echo [OK] All programs compiled successfully!
pause
goto MENU

:EXIT_SCRIPT
echo.
echo Thank you for using RailGo OS Simulation Suite. Goodbye!
exit /b 0
