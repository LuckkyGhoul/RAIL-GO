#include "os_common.h"

#define MAX_P 16
#define MAX_R 8

/* -------------------------------------------------------------------------
 * MODULE 1: Circular Wait Deadlock Demonstration & Prevention via Lock Order
 * ------------------------------------------------------------------------- */
void demonstrate_circular_wait_and_prevention(void) {
    print_header("DEADLOCK DEMONSTRATION & PREVENTION (CIRCULAR WAIT)",
                 "Simulating Resource Inversion Deadlock vs. Strict Lock Ordering Prevention");

    printf("  [SCENARIO: MULTI-RESOURCE BOOKING CONTENTION]\n");
    printf("  Two concurrent booking processes (P1 and P2) require TWO resources:\n");
    printf("    Resource A: [TRAIN BERTH INVENTORY LOCK]\n");
    printf("    Resource B: [PAYMENT GATEWAY BANK CHANNEL]\n\n");

    printf("  =========================================================================\n");
    printf("  CASE 1: DEADLOCK OCCURRENCE (WITHOUT PREVENTION)\n");
    printf("  =========================================================================\n");
    printf("  [Timeline of Execution]:\n");
    printf("   t = 0 ms : Process P1 requests and ACQUIRES Resource A (Berth Lock)\n");
    sleep_ms(300);
    printf("   t = 10 ms: Process P2 requests and ACQUIRES Resource B (Bank Channel)\n");
    sleep_ms(300);
    printf("   t = 20 ms: Process P1 holds Resource A and requests Resource B... [BLOCKED]\n");
    sleep_ms(300);
    printf("   t = 30 ms: Process P2 holds Resource B and requests Resource A... [BLOCKED]\n\n");
    sleep_ms(400);

    printf("  >>> DEADLOCK DETECTED! <<<\n");
    printf("  Both processes are waiting indefinitely for resources held by each other.\n\n");

    printf("  [ASCII RESOURCE ALLOCATION GRAPH (RAG) WITH CYCLE]:\n");
    printf("       +-----------------------+              +-----------------------+\n");
    printf("       |  Process P1 (Booking) |              |  Process P2 (Booking) |\n");
    printf("       +-----------------------+              +-----------------------+\n");
    printf("              |          ^                           ^          |\n");
    printf("        HOLDS |          | WAITS               HOLDS |          | WAITS\n");
    printf("              v          |                           v          |\n");
    printf("       ( Resource A: Berth )                  ( Resource B: Bank )\n");
    printf("              |          |                           |          |\n");
    printf("              +----------+---------------------------+----------+\n");
    printf("                               [CIRCULAR WAIT CYCLE]\n\n");

    printf("  [COFFMAN'S 4 CONDITIONS VERIFICATION]:\n");
    printf("    1. Mutual Exclusion : YES (Resources cannot be shared simultaneously)\n");
    printf("    2. Hold and Wait    : YES (P1 holds A while waiting for B; P2 holds B waiting for A)\n");
    printf("    3. No Preemption    : YES (Resources cannot be forcibly seized)\n");
    printf("    4. Circular Wait    : YES (P1 -> B -> P2 -> A -> P1)\n");
    printf("    ==> All 4 conditions hold simultaneously -> SYSTEM IS DEADLOCKED!\n\n");

    printf("  -------------------------------------------------------------------------\n");
    printf("  CASE 2: DEADLOCK PREVENTION (STRICT RESOURCE ORDERING: Havender's Algorithm)\n");
    printf("  -------------------------------------------------------------------------\n");
    printf("  [Prevention Rule]: Impose a strict linear ordering on resources: Order(A) = 1, Order(B) = 2.\n");
    printf("  All processes MUST acquire Resource A before requesting Resource B.\n\n");

    printf("  [Execution Timeline under Prevention]:\n");
    printf("   t = 0 ms : Process P1 requests and ACQUIRES Resource A.\n");
    sleep_ms(200);
    printf("   t = 5 ms : Process P2 attempts to acquire Resource A... [BLOCKED waiting for P1]\n");
    sleep_ms(200);
    printf("   t = 10 ms: Process P1 requests and ACQUIRES Resource B.\n");
    sleep_ms(200);
    printf("   t = 15 ms: Process P1 finishes booking, confirms seat, and RELEASES A & B!\n");
    sleep_ms(200);
    printf("   t = 20 ms: Process P2 is unblocked, ACQUIRES Resource A then B, and completes!\n\n");

    printf("  >>> SUCCESS: CIRCULAR WAIT ELIMINATED! 0 DEADLOCKS FORMED. <<<\n");
}

/* -------------------------------------------------------------------------
 * MODULE 2: Banker's Algorithm for Multi-Seat / Multi-Resource Train Booking
 * ------------------------------------------------------------------------- */
void demonstrate_bankers_algorithm(void) {
    print_header("DEADLOCK AVOIDANCE - BANKER'S ALGORITHM",
                 "Evaluating Safe State vs. Unsafe State for Seat & Channel Allocations");

    int n = read_int_bounded("Enter number of applicant booking processes", 2, MAX_P, 4);
    int m = read_int_bounded("Enter number of resource types (e.g. 1A, 2A, 3A seats)", 1, MAX_R, 3);

    const char *res_names[MAX_R] = { "AC-1A Seats", "AC-2A Seats", "AC-3A Seats", "Sleeper Seats" };

    int available[MAX_R];
    int max_claim[MAX_P][MAX_R];
    int allocation[MAX_P][MAX_R];
    int need[MAX_P][MAX_R];

    int input_choice = read_int_bounded("Matrix Input: [1 = Use realistic train booking defaults, 2 = Enter manually]", 1, 2, 1);

    if (input_choice == 1) {
        /* Realistic preset: 4 processes, 3 resource types */
        int def_avail[3] = { 3, 3, 2 };
        int def_alloc[4][3] = {
            { 0, 1, 0 }, /* P0 */
            { 2, 0, 0 }, /* P1 */
            { 3, 0, 2 }, /* P2 */
            { 2, 1, 1 }  /* P3 */
        };
        int def_max[4][3] = {
            { 7, 5, 3 }, /* P0 */
            { 3, 2, 2 }, /* P1 */
            { 9, 0, 2 }, /* P2 */
            { 2, 2, 2 }  /* P3 */
        };

        for (int j = 0; j < m; j++) available[j] = (j < 3) ? def_avail[j] : 2;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                allocation[i][j] = (i < 4 && j < 3) ? def_alloc[i][j] : 1;
                max_claim[i][j]  = (i < 4 && j < 3) ? def_max[i][j]   : 2;
            }
        }
    } else {
        printf("\nEnter Available instances for each resource:\n");
        for (int j = 0; j < m; j++) {
            char prompt[64];
            snprintf(prompt, sizeof(prompt), "  Available %s", (j < 4) ? res_names[j] : "Resource");
            available[j] = read_int_bounded(prompt, 0, 100, 3);
        }

        printf("\nEnter Allocation Matrix (currently granted seats/resources):\n");
        for (int i = 0; i < n; i++) {
            printf("  Process P%d:\n", i);
            for (int j = 0; j < m; j++) {
                char prompt[64];
                snprintf(prompt, sizeof(prompt), "    Allocated %s", (j < 4) ? res_names[j] : "Resource");
                allocation[i][j] = read_int_bounded(prompt, 0, 100, 1);
            }
        }

        printf("\nEnter Maximum Claim Matrix (maximum seats needed by each request):\n");
        for (int i = 0; i < n; i++) {
            printf("  Process P%d:\n", i);
            for (int j = 0; j < m; j++) {
                char prompt[64];
                snprintf(prompt, sizeof(prompt), "    Max Claim for %s", (j < 4) ? res_names[j] : "Resource");
                max_claim[i][j] = read_int_bounded(prompt, allocation[i][j], 100, allocation[i][j] + 1);
            }
        }
    }

    /* Compute Need Matrix: Need = Max - Allocation */
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            need[i][j] = max_claim[i][j] - allocation[i][j];
        }
    }

    /* Print System State Tables */
    printf("\n  =========================================================================\n");
    printf("  [SYSTEM STATE MATRICES: ALLOCATION, MAX CLAIM, NEED]\n");
    printf("  =========================================================================\n");
    printf("  Process |     Allocation      |      Max Claim      |        Need\n");
    printf("  --------+---------------------+---------------------+---------------------\n");
    for (int i = 0; i < n; i++) {
        printf("    P%-2d   | ", i);
        for (int j = 0; j < m; j++) printf("%-2d ", allocation[i][j]);
        printf("         | ");
        for (int j = 0; j < m; j++) printf("%-2d ", max_claim[i][j]);
        printf("        | ");
        for (int j = 0; j < m; j++) printf("%-2d ", need[i][j]);
        printf("\n");
    }
    printf("  --------+---------------------+---------------------+---------------------\n");
    printf("  Available Vector: [ ");
    for (int j = 0; j < m; j++) printf("%d ", available[j]);
    printf("]\n\n");

    /* Execute Banker's Safety Algorithm */
    printf("  [EXECUTING BANKER'S SAFETY ALGORITHM]\n");
    printf("  -------------------------------------------------------------------------\n");

    int work[MAX_R];
    bool finish[MAX_P];
    for (int j = 0; j < m; j++) work[j] = available[j];
    for (int i = 0; i < n; i++) finish[i] = false;

    int safe_seq[MAX_P];
    int count = 0;

    while (count < n) {
        bool found = false;
        for (int p = 0; p < n; p++) {
            if (!finish[p]) {
                bool can_allocate = true;
                for (int j = 0; j < m; j++) {
                    if (need[p][j] > work[j]) {
                        can_allocate = false;
                        break;
                    }
                }

                if (can_allocate) {
                    printf("  -> Process P%d can satisfy its Need [ ", p);
                    for (int j = 0; j < m; j++) printf("%d ", need[p][j]);
                    printf("] with Available Work [ ");
                    for (int j = 0; j < m; j++) printf("%d ", work[j]);
                    printf("]\n");

                    /* Process completes, returns allocated resources */
                    for (int j = 0; j < m; j++) {
                        work[j] += allocation[p][j];
                    }
                    safe_seq[count++] = p;
                    finish[p] = true;
                    found = true;

                    printf("     P%d finishes and releases resources. New Work Vector: [ ", p);
                    for (int j = 0; j < m; j++) printf("%d ", work[j]);
                    printf("]\n\n");
                    sleep_ms(150);
                }
            }
        }

        if (!found) {
            break;
        }
    }

    if (count == n) {
        printf("  =========================================================================\n");
        printf("  >>> RESULT: SYSTEM IS IN A SAFE STATE! <<<\n");
        printf("  Safe Execution Sequence: < ");
        for (int i = 0; i < n; i++) {
            printf("P%d%s", safe_seq[i], (i == n - 1) ? " " : " -> ");
        }
        printf(">\n");
        printf("  No deadlock can occur under this sequence of seat reservations!\n");
        printf("  =========================================================================\n");
    } else {
        printf("  =========================================================================\n");
        printf("  >>> RESULT: SYSTEM IS IN AN UNSAFE STATE! <<<\n");
        printf("  Deadlock condition possible. The reservation scheduler must delay or\n");
        printf("  reject further seat requests until existing allocations are released.\n");
        printf("  =========================================================================\n");
    }
}

int main(void) {
    while (1) {
        print_header("DEADLOCK SIMULATION & PREVENTION",
                     "Circular Wait, Coffman Conditions & Banker's Algorithm");

        printf("  [1] Circular Wait & Lock Ordering Prevention\n");
        printf("  [2] Banker's Algorithm (Safe Allocation Sequence)\n");
        printf("  [0] Return to Main Menu\n\n");

        int choice = read_int_bounded("Select Option", 0, 2, 1);
        if (choice == 0) break;
        if (choice == 1) {
            demonstrate_circular_wait_and_prevention();
        } else if (choice == 2) {
            demonstrate_bankers_algorithm();
        }
        press_enter_to_continue();
    }
    return 0;
}
