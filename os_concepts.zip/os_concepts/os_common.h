#ifndef OS_COMMON_H
#define OS_COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif

/* Terminal styling helpers */
static inline void clear_screen(void) {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

static inline void sleep_ms(int ms) {
#ifdef _WIN32
    Sleep(ms);
#else
    usleep(ms * 1000);
#endif
}

/* Print banner helper */
static inline void print_header(const char *title, const char *subtitle) {
    printf("\n");
    printf("===============================================================================\n");
    printf("  [IRCTC OS SIMULATION] %s\n", title);
    if (subtitle && strlen(subtitle) > 0) {
        printf("  %s\n", subtitle);
    }
    printf("===============================================================================\n\n");
}

/* Safe integer reader */
static inline int read_int_bounded(const char *prompt, int min_val, int max_val, int default_val) {
    char buffer[64];
    int value = default_val;
    while (1) {
        printf("%s [%d-%d, default %d]: ", prompt, min_val, max_val, default_val);
        if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
            return default_val;
        }
        /* Trim newline */
        char *nl = strchr(buffer, '\n');
        if (nl) *nl = '\0';

        if (strlen(buffer) == 0) {
            return default_val;
        }
        if (sscanf(buffer, "%d", &value) == 1 && value >= min_val && value <= max_val) {
            return value;
        }
        printf("  [!] Invalid input. Please enter an integer between %d and %d.\n", min_val, max_val);
    }
}

/* Safe string reader */
static inline void read_string_default(const char *prompt, char *dest, size_t dest_size, const char *default_val) {
    char buffer[128];
    printf("%s [default: %s]: ", prompt, default_val);
    if (fgets(buffer, sizeof(buffer), stdin) == NULL || strlen(buffer) <= 1) {
        snprintf(dest, dest_size, "%s", default_val);
        return;
    }
    char *nl = strchr(buffer, '\n');
    if (nl) *nl = '\0';

    if (strlen(buffer) == 0) {
        snprintf(dest, dest_size, "%s", default_val);
    } else {
        snprintf(dest, dest_size, "%s", buffer);
    }
}

/* Wait for Enter key */
static inline void press_enter_to_continue(void) {
    printf("\nPress [ENTER] to return to menu...");
    while (getchar() != '\n');
}

#endif /* OS_COMMON_H */
