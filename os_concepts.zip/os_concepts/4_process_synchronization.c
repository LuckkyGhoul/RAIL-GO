#include "os_common.h"

#define MAX_THREADS 32

/* Global Shared State */
static volatile int g_available_seats = 0;
static volatile int g_confirmed_count = 0;
static volatile int g_waitlisted_count = 0;

typedef struct {
    int thread_id;
    int pid;
    char pax_name[32];
    bool booked;
    int seat_num;
    bool is_duplicate;
} ThreadResult;

static ThreadResult g_results[MAX_THREADS];

#ifdef _WIN32
static CRITICAL_SECTION g_cs_lock;
static HANDLE g_threads[MAX_THREADS];
#else
#include <pthread.h>
static pthread_mutex_t g_mutex_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_t g_threads[MAX_THREADS];
#endif

typedef struct {
    int thread_idx;
    bool use_synchronization;
} ThreadArg;

/* -------------------------------------------------------------
 * Thread Worker Function (Simulating Concurrent Booking)
 * ------------------------------------------------------------- */
#ifdef _WIN32
DWORD WINAPI booking_thread_func(LPVOID lpParam)
#else
void *booking_thread_func(void *lpParam)
#endif
{
    ThreadArg *arg = (ThreadArg *)lpParam;
    int idx = arg->thread_idx;
    bool sync = arg->use_synchronization;

    if (sync) {
#ifdef _WIN32
        EnterCriticalSection(&g_cs_lock);
#else
        pthread_mutex_lock(&g_mutex_lock);
#endif
    }

    /* === CRITICAL SECTION (Accessing & Modifying Shared Inventory) === */
    int current_seats = g_available_seats;

    /* Intentional context switch delay in un-synchronized mode
     * to reveal race condition windows where threads interleave */
    if (!sync) {
        sleep_ms(15);
    }

    if (current_seats > 0) {
        /* Allocate seat */
        int assigned = current_seats;
        g_available_seats = current_seats - 1;
        g_confirmed_count++;

        g_results[idx].booked = true;
        g_results[idx].seat_num = assigned;
        printf("  [Thread %2d (PID %d)]: -> BOOKED Berth #%d (Seats left: %d)\n",
               idx + 1, g_results[idx].pid, assigned, g_available_seats);
    } else {
        /* Out of seats */
        g_results[idx].booked = false;
        g_results[idx].seat_num = -1;
        g_waitlisted_count++;
        printf("  [Thread %2d (PID %d)]: -> FAILED. Berths full! [WAITLISTED / REFUND]\n",
               idx + 1, g_results[idx].pid);
    }
    /* === END OF CRITICAL SECTION === */

    if (sync) {
#ifdef _WIN32
        LeaveCriticalSection(&g_cs_lock);
#else
        pthread_mutex_unlock(&g_mutex_lock);
#endif
    }

#ifdef _WIN32
    return 0;
#else
    return NULL;
#endif
}

void run_concurrency_test(int initial_seats, int num_threads, bool use_sync) {
    /* Reset shared state */
    g_available_seats = initial_seats;
    g_confirmed_count = 0;
    g_waitlisted_count = 0;

    for (int i = 0; i < num_threads; i++) {
        g_results[i].thread_id = i + 1;
        g_results[i].pid = 3001 + i;
        snprintf(g_results[i].pax_name, sizeof(g_results[i].pax_name), "Passenger%d", i + 1);
        g_results[i].booked = false;
        g_results[i].seat_num = -1;
        g_results[i].is_duplicate = false;
    }

#ifdef _WIN32
    if (use_sync) {
        InitializeCriticalSection(&g_cs_lock);
    }
#endif

    ThreadArg args[MAX_THREADS];
    printf("\n  Spawning %d concurrent OS threads competing for %d shared seats...\n\n",
           num_threads, initial_seats);

    /* Launch threads */
    for (int i = 0; i < num_threads; i++) {
        args[i].thread_idx = i;
        args[i].use_synchronization = use_sync;
#ifdef _WIN32
        g_threads[i] = CreateThread(NULL, 0, booking_thread_func, &args[i], 0, NULL);
#else
        pthread_create(&g_threads[i], NULL, booking_thread_func, &args[i]);
#endif
    }

    /* Wait for all threads to terminate */
#ifdef _WIN32
    WaitForMultipleObjects(num_threads, g_threads, TRUE, INFINITE);
    for (int i = 0; i < num_threads; i++) {
        CloseHandle(g_threads[i]);
    }
    if (use_sync) {
        DeleteCriticalSection(&g_cs_lock);
    }
#else
    for (int i = 0; i < num_threads; i++) {
        pthread_join(g_threads[i], NULL);
    }
#endif

    /* Detect duplicate berth allocations */
    int duplicate_count = 0;
    for (int i = 0; i < num_threads; i++) {
        if (g_results[i].booked) {
            for (int j = i + 1; j < num_threads; j++) {
                if (g_results[j].booked && g_results[i].seat_num == g_results[j].seat_num) {
                    g_results[i].is_duplicate = true;
                    g_results[j].is_duplicate = true;
                    duplicate_count++;
                }
            }
        }
    }

    /* Print Results Table */
    printf("\n  =========================================================================\n");
    printf("  [CONCURRENCY OUTCOME: %s]\n", use_sync ? "WITH SYNCHRONIZATION (MUTEX)" : "WITHOUT SYNCHRONIZATION (RACE CONDITION)");
    printf("  =========================================================================\n");
    printf("  Thread |   PID   | Passenger Name | Status     | Berth No | Contention Anomaly\n");
    printf("  -------+---------+----------------+------------+----------+--------------------\n");
    for (int i = 0; i < num_threads; i++) {
        char status_str[16];
        char berth_str[16];
        char anomaly_str[32];

        if (g_results[i].booked) {
            strncpy(status_str, "CONFIRMED", sizeof(status_str));
            snprintf(berth_str, sizeof(berth_str), "Berth #%d", g_results[i].seat_num);
            if (g_results[i].is_duplicate) {
                snprintf(anomaly_str, sizeof(anomaly_str), "[!] DUPLICATE SEAT BOOKED");
            } else {
                snprintf(anomaly_str, sizeof(anomaly_str), "OK (Clean Allocation)");
            }
        } else {
            strncpy(status_str, "WAITLIST", sizeof(status_str));
            strncpy(berth_str, "None", sizeof(berth_str));
            snprintf(anomaly_str, sizeof(anomaly_str), "Auto-Refund Initiated");
        }

        printf("  T%-5d | P%-6d | %-14s | %-10s | %-8s | %s\n",
               g_results[i].thread_id, g_results[i].pid, g_results[i].pax_name,
               status_str, berth_str, anomaly_str);
    }
    printf("  =========================================================================\n");

    printf("\n  [ANALYSIS & VIVA METRICS]\n");
    printf("  -------------------------------------------------------------------------\n");
    printf("  * Initial Available Seats     : %d\n", initial_seats);
    printf("  * Total Booking Threads       : %d\n", num_threads);
    printf("  * Total Confirmed Bookings    : %d\n", g_confirmed_count);
    printf("  * Remaining Seat Counter in DB: %d\n", g_available_seats);
    printf("  * Duplicate Berth Collisions  : %d\n", duplicate_count);

    if (!use_sync) {
        printf("  [RESULT]: RACE CONDITION DETECTED! Unsynchronized threads caused Overbooking & Collisions!\n");
    } else {
        printf("  [RESULT]: MUTEX VERIFIED! Mutual exclusion enforced -> Exactly %d berths allocated cleanly.\n", initial_seats);
    }
    printf("  -------------------------------------------------------------------------\n");
}

int main(void) {
    while (1) {
        print_header("PROCESS SYNCHRONIZATION & CRITICAL SECTION",
                     "Race Condition Bug vs. Mutex Lock Protection");

        printf("  [1] WITHOUT Synchronization (Expose Race Condition Bug)\n");
        printf("  [2] WITH Synchronization (Mutual Exclusion via Mutex)\n");
        printf("  [3] Comparative Side-by-Side Demonstration\n");
        printf("  [0] Return to Main Menu\n\n");

        int choice = read_int_bounded("Select Option", 0, 3, 3);
        if (choice == 0) break;

        int initial_seats = read_int_bounded("Enter available train seats/berths", 1, 20, 3);
        int num_threads   = read_int_bounded("Enter concurrent booking threads", 2, MAX_THREADS, 8);

        if (choice == 1) {
            run_concurrency_test(initial_seats, num_threads, false);
        } else if (choice == 2) {
            run_concurrency_test(initial_seats, num_threads, true);
        } else if (choice == 3) {
            printf("\n\n>>> PART 1: EXPOSING THE RACE CONDITION (NO LOCK) <<<\n");
            run_concurrency_test(initial_seats, num_threads, false);

            printf("\n\n>>> Press [ENTER] to run PART 2: SOLVING WITH SYNCHRONIZATION (MUTEX) <<<");
            getchar();

            run_concurrency_test(initial_seats, num_threads, true);
        }

        press_enter_to_continue();
    }
    return 0;
}
