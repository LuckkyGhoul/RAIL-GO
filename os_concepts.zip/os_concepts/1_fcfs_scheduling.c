#include "os_common.h"

#define MAX_REQUESTS 64

typedef struct {
    int pid;
    char pax_name[32];
    int arrival_time;   /* AT: When request reached the server queue */
    int burst_time;     /* BT: CPU time to validate, reserve, generate PNR */
    int start_time;     /* ST: When CPU actually started processing */
    int completion_time;/* CT: When booking was finished */
    int turnaround_time;/* TAT = CT - AT */
    int waiting_time;   /* WT = TAT - BT */
    int response_time;  /* RT = ST - AT */
    bool allocated;     /* True if seat was successfully confirmed */
    int seat_no;        /* Assigned seat number if confirmed */
    char status[32];    /* "CNF (Berth #X)" or "WAITLISTED (Refund)" */
} BookingProcess;

typedef struct {
    int pid;
    char label[32];
    int start;
    int end;
    bool is_idle;
} GanttSegment;

/* Stable sorting by arrival time */
void sort_by_arrival(BookingProcess proc[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (proc[j].arrival_time > proc[j + 1].arrival_time ||
               (proc[j].arrival_time == proc[j + 1].arrival_time && proc[j].pid > proc[j + 1].pid)) {
                BookingProcess temp = proc[j];
                proc[j] = proc[j + 1];
                proc[j + 1] = temp;
            }
        }
    }
}

/* Render ASCII Gantt Chart */
void print_gantt_chart(GanttSegment segments[], int seg_count) {
    printf("\n  =========================================================================\n");
    printf("  [VISUAL GANTT CHART - CPU PROCESSING TIMELINE (FCFS)]\n");
    printf("  =========================================================================\n\n");

    /* Top border */
    printf("  +");
    for (int i = 0; i < seg_count; i++) {
        int width = 8;
        for (int w = 0; w < width; w++) printf("-");
        printf("+");
    }
    printf("\n");

    /* Process Labels */
    printf("  |");
    for (int i = 0; i < seg_count; i++) {
        if (segments[i].is_idle) {
            printf("  IDLE  |");
        } else {
            printf("  P%-3d  |", segments[i].pid);
        }
    }
    printf("\n");

    /* Bottom border */
    printf("  +");
    for (int i = 0; i < seg_count; i++) {
        int width = 8;
        for (int w = 0; w < width; w++) printf("-");
        printf("+");
    }
    printf("\n");

    /* Time markers */
    printf("  %-2d", segments[0].start);
    for (int i = 0; i < seg_count; i++) {
        printf("       %-2d", segments[i].end);
    }
    printf("\n\n");
}

int main(void) {
    print_header("FCFS CPU & TICKET SCHEDULING",
                 "First-Come, First-Served CPU Burst Scheduling + Inventory Allocation");

    int available_seats = read_int_bounded("Available train berths", 1, 100, 3);
    int num_passengers  = read_int_bounded("Total passenger requests", 1, MAX_REQUESTS, 6);
    int auto_mode       = read_int_bounded("Input mode: [1 = Auto-generate AT/BT, 2 = Manual]", 1, 2, 1);

    BookingProcess proc[MAX_REQUESTS];
    int base_pid = 1001;

    for (int i = 0; i < num_passengers; i++) {
        proc[i].pid = base_pid + i;
        proc[i].allocated = false;
        proc[i].seat_no = -1;

        char default_name[32];
        snprintf(default_name, sizeof(default_name), "Passenger%d", i + 1);

        if (auto_mode == 2) {
            printf("\n--- Passenger %d of %d ---\n", i + 1, num_passengers);
            read_string_default("Enter Passenger Name", proc[i].pax_name, sizeof(proc[i].pax_name), default_name);
            proc[i].arrival_time = read_int_bounded("Arrival Time (AT in ms)", 0, 1000, i * 2);
            proc[i].burst_time   = read_int_bounded("Burst / Processing Time (BT in ms)", 1, 50, (i % 3 + 2) * 2);
        } else {
            /* Auto-generate realistic diverse arrival times and CPU burst times */
            strncpy(proc[i].pax_name, default_name, sizeof(proc[i].pax_name));
            /* Progressive arrivals with slight delays */
            proc[i].arrival_time = i * 2;
            /* Diverse CPU validation times (3ms - 8ms) */
            proc[i].burst_time = 3 + (i * 7) % 6;
        }
    }

    /* Step 1: Sort by Arrival Time for FCFS */
    sort_by_arrival(proc, num_passengers);

    /* Step 2: Simulate FCFS Scheduling & Gantt Segments */
    GanttSegment segments[MAX_REQUESTS * 2];
    int seg_count = 0;

    int current_time = 0;
    int remaining_seats = available_seats;
    int total_busy_time = 0;

    for (int i = 0; i < num_passengers; i++) {
        /* Check if CPU was idle before this process arrived */
        if (current_time < proc[i].arrival_time) {
            segments[seg_count].pid = -1;
            strncpy(segments[seg_count].label, "IDLE", sizeof(segments[seg_count].label));
            segments[seg_count].start = current_time;
            segments[seg_count].end = proc[i].arrival_time;
            segments[seg_count].is_idle = true;
            seg_count++;
            current_time = proc[i].arrival_time;
        }

        proc[i].start_time = current_time;
        proc[i].completion_time = proc[i].start_time + proc[i].burst_time;
        proc[i].turnaround_time = proc[i].completion_time - proc[i].arrival_time;
        proc[i].waiting_time = proc[i].turnaround_time - proc[i].burst_time;
        proc[i].response_time = proc[i].start_time - proc[i].arrival_time;

        total_busy_time += proc[i].burst_time;

        /* Record Gantt block */
        segments[seg_count].pid = proc[i].pid;
        strncpy(segments[seg_count].label, proc[i].pax_name, sizeof(segments[seg_count].label));
        segments[seg_count].start = current_time;
        segments[seg_count].end = proc[i].completion_time;
        segments[seg_count].is_idle = false;
        seg_count++;

        current_time = proc[i].completion_time;

        /* Seat allocation upon CPU completion */
        if (remaining_seats > 0) {
            proc[i].allocated = true;
            proc[i].seat_no = (available_seats - remaining_seats) + 1;
            remaining_seats--;
            snprintf(proc[i].status, sizeof(proc[i].status), "CNF (Berth #%d)", proc[i].seat_no);
        } else {
            proc[i].allocated = false;
            proc[i].seat_no = -1;
            snprintf(proc[i].status, sizeof(proc[i].status), "WL #%d (Refund)", (i + 1) - available_seats);
        }
    }

    /* Print Visual Gantt Chart */
    print_gantt_chart(segments, seg_count);

    /* Print Scheduling Execution Table */
    printf("  =========================================================================================================\n");
    printf("  [FCFS EXECUTION & TICKET ALLOCATION RESULTS]\n");
    printf("  =========================================================================================================\n");
    printf("  %-6s | %-14s | %-4s | %-4s | %-4s | %-5s | %-4s | %-4s | %-20s\n",
           "PID", "Passenger", "AT", "BT", "CT", "TAT", "WT", "RT", "Final Status");
    printf("  -------+----------------+------+------+------+-------+------+------+-------------------------------------\n");

    double sum_tat = 0.0, sum_wt = 0.0, sum_rt = 0.0;
    int confirmed_count = 0;

    for (int i = 0; i < num_passengers; i++) {
        printf("  P%-5d | %-14s | %-4d | %-4d | %-4d | %-5d | %-4d | %-4d | %-20s\n",
               proc[i].pid, proc[i].pax_name,
               proc[i].arrival_time, proc[i].burst_time,
               proc[i].completion_time, proc[i].turnaround_time,
               proc[i].waiting_time, proc[i].response_time,
               proc[i].status);

        sum_tat += proc[i].turnaround_time;
        sum_wt  += proc[i].waiting_time;
        sum_rt  += proc[i].response_time;
        if (proc[i].allocated) confirmed_count++;
    }
    printf("  =========================================================================================================\n");

    int total_time = current_time;
    double avg_tat = sum_tat / num_passengers;
    double avg_wt  = sum_wt / num_passengers;
    double cpu_util = ((double)total_busy_time / total_time) * 100.0;

    printf("\n  [METRICS]: Total Time = %d ms | Avg TAT = %.2f ms | Avg WT = %.2f ms | CPU Util = %.1f%%\n",
           total_time, avg_tat, avg_wt, cpu_util);
    printf("  [RESULT] : %d Berths CONFIRMED, %d WAITLISTED (Refund Initiated)\n",
           confirmed_count, num_passengers - confirmed_count);
    printf("  =========================================================================================================\n");

    press_enter_to_continue();
    return 0;
}
