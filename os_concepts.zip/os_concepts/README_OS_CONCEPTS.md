# IRCTC Ticket Reservation System - Operating System (OS) Concepts Suite

This module provides **C-based Operating System simulations** specifically mapped to the real-world scenarios of an online railway ticket booking system (IRCTC Tatkal / General reservation).

It satisfies academic OS curriculum requirements, lab practicals, and university viva examinations by demonstrating:
1. **FCFS CPU & Ticket Scheduling** (Gantt Chart, Turnaround Time, Waiting Time, Throughput).
2. **Process Management & PCB Lifecycle** (5-State Model, Process Control Blocks, Context Switching, I/O Blocking).
3. **Deadlock Simulation & Prevention** (Circular Wait, Resource Allocation Graph, Coffman's Conditions, Havender's Linear Ordering, and Banker's Algorithm).
4. **Process Synchronization & Race Condition Prevention** (Real OS Multi-Threading, Critical Section Problem, Race Condition Overbooking Bug vs. Mutex Protection).

---

## Folder Structure

```
train_booking_system/
├── run_os_simulations.bat              <-- Root shortcut to launch the OS suite
├── os_concepts/                        <-- Dedicated OS simulation module
│   ├── os_common.h                     <-- Shared utilities, headers, input validators
│   ├── 1_fcfs_scheduling.c             <-- Concept 1: FCFS Scheduling & Gantt Chart
│   ├── 2_process_management.c          <-- Concept 2: PCB & 5-State Process Model
│   ├── 3_deadlock_simulation.c         <-- Concept 3: Circular Wait & Banker's Algorithm
│   ├── 4_process_synchronization.c     <-- Concept 4: Multithreaded Mutex & Race Condition
│   ├── run_os_simulations.bat          <-- Interactive menu-driven launcher
│   ├── README_OS_CONCEPTS.md           <-- Complete documentation & Viva preparation guide
│   ├── 1_fcfs_scheduling.exe           <-- Compiled binary
│   ├── 2_process_management.exe        <-- Compiled binary
│   ├── 3_deadlock_simulation.exe       <-- Compiled binary
│   └── 4_process_synchronization.exe   <-- Compiled binary
```

---

## How to Run the Simulations

### Option 1: Using the Interactive Batch Launcher (Recommended)
Open Command Prompt or PowerShell in the project directory:
```powershell
cd C:\Users\Luckky\Desktop\train_booking_system\train_booking_system
.\run_os_simulations.bat
```
*(Or double-click `run_os_simulations.bat` directly in Windows Explorer).*

You will see the menu:
```
===============================================================================
    INDIAN RAILWAY CATERING AND TOURISM CORPORATION (IRCTC)
       OPERATING SYSTEM (OS) CORE CONCEPTS SIMULATION SUITE
===============================================================================
  [1] FCFS CPU Scheduling Simulation
  [2] Process Management & PCB Lifecycle
  [3] Deadlock Simulation, Prevention & Banker's Algorithm
  [4] Process Synchronization & Race Condition (Multithreaded)
  [5] Recompile All C Programs
  [0] Exit
===============================================================================
```

### Option 2: Compiling & Running Manually via GCC
You can compile and run any individual program directly:
```powershell
cd os_concepts

# Compile Concept 1 (FCFS)
gcc -Wall -Wextra -O2 1_fcfs_scheduling.c -o 1_fcfs_scheduling.exe
.\1_fcfs_scheduling.exe

# Compile Concept 2 (Process Management)
gcc -Wall -Wextra -O2 2_process_management.c -o 2_process_management.exe
.\2_process_management.exe

# Compile Concept 3 (Deadlocks)
gcc -Wall -Wextra -O2 3_deadlock_simulation.c -o 3_deadlock_simulation.exe
.\3_deadlock_simulation.exe

# Compile Concept 4 (Process Synchronization with Threads)
gcc -Wall -Wextra -O2 4_process_synchronization.c -o 4_process_synchronization.exe
.\4_process_synchronization.exe
```

---

## Detailed OS Concept Breakdown

### 1. FCFS Scheduling (`1_fcfs_scheduling.c`)

#### Academic Theory vs. Project Mapping
* **CPU Scheduling FCFS:** Server CPU processes incoming passenger booking requests non-preemptively in the order they arrive in the ready queue.
* **Ticket Queue FCFS:** When CPU finishes processing, it allocates available berths in the same arrival order until berths are exhausted. Later requests are placed in the Waiting List (`WL`).

#### Mathematical Formulas
$$\text{Completion Time } (CT_i) = \text{Start Time } (ST_i) + \text{Burst Time } (BT_i)$$
$$\text{Turnaround Time } (TAT_i) = CT_i - AT_i$$
$$\text{Waiting Time } (WT_i) = TAT_i - BT_i$$
$$\text{Average Waiting Time} = \frac{\sum WT_i}{N}$$
$$\text{CPU Utilization} = \left(\frac{\text{Total Busy Time}}{\text{Total Schedule Time}}\right) \times 100\%$$

#### Features Demonstrated
* Real-time sorting by Arrival Time ($AT$).
* CPU Idle time tracking between non-contiguous request arrivals.
* **ASCII Visual Gantt Chart** displaying exact millisecond timeline intervals.
* Seat allocation table indicating `CONFIRMED (Berth #X)` or `WAITLISTED (Refund)`.

---

### 2. Process Management (`2_process_management.c`)

#### Academic Theory vs. Project Mapping
* Every ticket booking request is represented as an independent **Process** with a unique **Process ID (PID)** and an allocated **Process Control Block (PCB)** in memory.
* Demonstrates the classic **5-State Process Lifecycle**:
  1. **NEW:** Process created via `sys_fork()`, PCB initialized with PNR and passenger name.
  2. **READY:** Long-Term Scheduler admits process into the Ready Queue.
  3. **RUNNING:** Short-Term Scheduler dispatches process to CPU; context switch occurs.
  4. **WAITING (I/O):** Process yields CPU while waiting for external I/O (Bank Payment Gateway / SMS Gateway).
  5. **TERMINATED:** Process finishes, claims available berth or initiates refund, reports exit status, and PCB memory is reclaimed by the operating system.

#### Features Demonstrated
* Formatted **Process Table snapshots** displayed at each state transition.
* Realistic CPU and I/O burst simulation.
* Context switch logging showing CPU register / state transitions.

---

### 3. Deadlock Simulation & Prevention (`3_deadlock_simulation.c`)

#### Academic Theory vs. Project Mapping
In online reservation systems, bookings require multiple shared resources:
* **Resource A:** Train Coach Berth Inventory Lock
* **Resource B:** Payment Gateway Transaction Channel
* **Resource C:** PNR Database Row Lock

#### Module 3A: Circular Wait & Coffman's Conditions
* **Case 1 (Deadlock Occurrence):** Process $P_1$ holds Resource A and waits for Resource B. Concurrently, Process $P_2$ holds Resource B and waits for Resource A.
* Verifies **Coffman's 4 Necessary Conditions**:
  1. *Mutual Exclusion*
  2. *Hold and Wait*
  3. *No Preemption*
  4. *Circular Wait*
* Displays an **ASCII Resource Allocation Graph (RAG)** showing the circular wait cycle.

#### Module 3B: Deadlock Prevention via Resource Hierarchy (Havender's Algorithm)
* Imposes a strict linear lock ordering ($R_A < R_B$).
* Eliminates the Circular Wait condition entirely. All processes must acquire Resource A before Resource B.

#### Module 3C: Deadlock Avoidance via Banker's Algorithm
* Evaluates **Allocation Matrix**, **Maximum Claim Matrix**, and **Available Vector**.
* Computes **Need Matrix**:
  $$\text{Need}[i][j] = \text{Max}[i][j] - \text{Allocation}[i][j]$$
* Executes the Safety Algorithm to determine whether the system is in a **Safe State** or **Unsafe State**, printing the **Safe Execution Sequence** (e.g., $\langle P_1 \rightarrow P_3 \rightarrow P_0 \rightarrow P_2 \rangle$).

---

### 4. Process Synchronization (`4_process_synchronization.c`)

#### Academic Theory vs. Project Mapping
When multiple users book tickets simultaneously (e.g. at 10:00 AM Tatkal opening), multiple threads attempt to read and decrement the shared variable `available_seats`.

#### Features Demonstrated (Real Windows/POSIX Threads)
* **Mode 1: WITHOUT SYNCHRONIZATION (Race Condition Bug)**
  * Multiple threads enter the critical section simultaneously.
  * Artificial context switch reveals race condition windows where threads read stale inventory.
  * **Result:** Duplicate berth allocations and catastrophic **Overbooking Bug** (e.g., 8 passengers all get confirmed for only 3 available seats).
* **Mode 2: WITH SYNCHRONIZATION (Mutex / Critical Section)**
  * Mutual exclusion enforced via `EnterCriticalSection` / `LeaveCriticalSection` (or `pthread_mutex_lock`).
  * **Result:** Clean serialization! Exactly 3 passengers receive berths; remaining 5 threads are safely notified of seat exhaustion and waitlisted. Zero duplicates.

---

## OS Viva Preparation Guide (Questions Teachers Ask)

### Q1: Why is FCFS CPU scheduling different from ticket queue FCFS?
**Answer:** Ticket queue FCFS refers to the logical arrival order of passenger requests in the reservation queue. CPU scheduling FCFS refers to how the OS short-term scheduler assigns CPU processing time (burst time) to validate user credentials, compute fares, and generate PNRs. A request that arrives first gets the CPU first, and upon completing its CPU burst, claims available seat inventory.

### Q2: What is a Process Control Block (PCB) and what does it hold?
**Answer:** A PCB is a kernel data structure that stores all information required to manage a process: Process ID (PID), Process State, Program Counter, CPU registers, CPU scheduling priority, memory limits, and I/O status (e.g., PNR and allocated berth).

### Q3: What are Coffman's 4 conditions for deadlock?
**Answer:**
1. Mutual Exclusion (non-shareable resources).
2. Hold and Wait (process holds resources while requesting more).
3. No Preemption (resources cannot be forcibly taken).
4. Circular Wait (a closed chain of processes each waiting for a resource held by the next).
Deadlock can only occur if ALL four conditions hold simultaneously.

### Q4: How does linear resource ordering prevent deadlock?
**Answer:** By assigning each resource a global integer index ($R_1 < R_2 < R_3$) and requiring all processes to request resources in strictly ascending order, a circular wait cycle becomes mathematically impossible.

### Q5: What are the three criteria of the Critical Section Problem?
**Answer:**
1. **Mutual Exclusion:** If process $P_i$ is executing in its critical section, no other process can be executing in its critical section.
2. **Progress:** If no process is executing in its critical section and some processes wish to enter, selection cannot be postponed indefinitely.
3. **Bounded Waiting:** There must be a bound on the number of times other processes are allowed to enter their critical sections after a process has made a request.
