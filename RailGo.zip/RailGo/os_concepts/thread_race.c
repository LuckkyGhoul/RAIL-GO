#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <windows.h>
#include <psapi.h>

#define MAX_THREADS 200000
#define MAX_WINNERS 64
#define CONCURRENCY_WINDOW 2000

typedef struct {
    int req_index;
    DWORD os_tid;
    DWORD os_pid;
    char pax_name[32];
    int seat_no;
    double finish_ms;
} WinnerInfo;

typedef struct {
    int index;
    uint32_t iterations;
} ThreadParam;

/* Shared OS-synchronized state */
static volatile LONG g_total_threads = 100000;
static volatile LONG g_total_seats = 4;
static volatile LONG g_threads_finished = 0;
static volatile LONG g_waitlisted_count = 0;
static volatile LONG g_winner_count = 0;

static WinnerInfo g_winners[MAX_WINNERS];
static CRITICAL_SECTION g_seat_cs;
static HANDLE g_concurrency_sem = NULL;
static HANDLE g_all_done_event = NULL;
static LARGE_INTEGER g_freq;
static LARGE_INTEGER g_race_start;

/* CPU-intensive hash/compute routine to load all CPU cores */
static uint64_t burn_cpu_cycles(int seed, uint32_t iterations) {
    volatile uint64_t h = 0x9e3779b97f4a7c15ULL ^ (uint64_t)seed;
    for (uint32_t i = 1; i <= iterations; i++) {
        h ^= h >> 30;
        h *= 0xbf58476d1ce4e5b9ULL;
        h ^= h >> 27;
        h *= 0x94d049bb133111ebULL;
        h ^= (uint64_t)i;
    }
    return h;
}

DWORD WINAPI passenger_thread_worker(LPVOID lpParam) {
    ThreadParam *p = (ThreadParam *)lpParam;
    int idx = p->index;
    DWORD tid = GetCurrentThreadId();
    DWORD pid = GetCurrentProcessId();

    /* Real CPU-bound work across all logical cores */
    volatile uint64_t checksum = burn_cpu_cycles(idx + (int)tid, p->iterations);
    (void)checksum;

    /* CRITICAL SECTION: Atomic seat contention check & allocation */
    EnterCriticalSection(&g_seat_cs);
    LONG done = g_threads_finished;

    /* Stagger seat availability checkpoints across the race so all waves contend */
    LONG seats_unlocked = 1;
    if (g_total_seats > 1) {
        LONG step = g_total_threads / g_total_seats;
        if (step > 0) {
            seats_unlocked = 1 + (done / step);
            if (seats_unlocked > g_total_seats) seats_unlocked = g_total_seats;
        } else {
            seats_unlocked = g_total_seats;
        }
    }

    if (g_winner_count < seats_unlocked && g_winner_count < g_total_seats) {
        LONG w_idx = g_winner_count;
        if (w_idx < MAX_WINNERS) {
            LARGE_INTEGER now;
            QueryPerformanceCounter(&now);
            double elapsed = (double)(now.QuadPart - g_race_start.QuadPart) * 1000.0 / (double)g_freq.QuadPart;

            g_winners[w_idx].req_index = idx;
            g_winners[w_idx].os_tid = tid;
            g_winners[w_idx].os_pid = pid;
            snprintf(g_winners[w_idx].pax_name, sizeof(g_winners[w_idx].pax_name), "Passenger%d", idx);
            g_winners[w_idx].seat_no = (int)(w_idx + 1);
            g_winners[w_idx].finish_ms = elapsed;
            g_winner_count++;
        }
    } else {
        g_waitlisted_count++;
    }
    LeaveCriticalSection(&g_seat_cs);

    LONG finished_now = InterlockedIncrement(&g_threads_finished);
    ReleaseSemaphore(g_concurrency_sem, 1, NULL);

    if (finished_now >= g_total_threads) {
        SetEvent(g_all_done_event);
    }

    return 0;
}

static double filetime_to_ms(FILETIME ft) {
    ULARGE_INTEGER ui;
    ui.LowPart = ft.dwLowDateTime;
    ui.HighPart = ft.dwHighDateTime;
    return (double)ui.QuadPart / 10000.0;
}

int main(int argc, char *argv[]) {
    int num_threads = 100000;
    int num_seats = 4;
    const char *train_no = "ALL";

    if (argc >= 2) {
        int t = atoi(argv[1]);
        if (t >= 10 && t <= MAX_THREADS) num_threads = t;
    }
    if (argc >= 3) {
        int s = atoi(argv[2]);
        if (s >= 1 && s <= MAX_WINNERS) num_seats = s;
    }
    if (argc >= 4) {
        train_no = argv[3];
    }

    /* Buffered stdout so printing 100,000 live lines stays fast and smooth */
    static char stdout_buf[65536];
    setvbuf(stdout, stdout_buf, _IOFBF, sizeof(stdout_buf));

    g_total_threads = num_threads;
    g_total_seats = num_seats;

    DWORD host_pid = GetCurrentProcessId();
    SYSTEM_INFO sysinfo;
    GetSystemInfo(&sysinfo);

    printf("======================================================================\n");
    printf("  RAILGO OS THREAD RACE | Train: %-8s | PID: %lu | CPU Cores: %lu\n",
           train_no, (unsigned long)host_pid, (unsigned long)sysinfo.dwNumberOfProcessors);
    printf("  Target Threads: %d | Seats: %d | Active Window: %d\n",
           num_threads, num_seats, CONCURRENCY_WINDOW);
    printf("  Sync: Windows CRITICAL_SECTION + Kernel Semaphore\n");
    printf("======================================================================\n");
    fflush(stdout);

    InitializeCriticalSection(&g_seat_cs);
    g_concurrency_sem = CreateSemaphore(NULL, CONCURRENCY_WINDOW, CONCURRENCY_WINDOW, NULL);
    g_all_done_event = CreateEvent(NULL, TRUE, FALSE, NULL);
    QueryPerformanceFrequency(&g_freq);

    ThreadParam *params = (ThreadParam *)calloc((size_t)num_threads, sizeof(ThreadParam));
    if (!params || !g_concurrency_sem || !g_all_done_event) {
        fprintf(stderr, "[ERROR] Failed to initialize OS resources.\n");
        return 1;
    }

    QueryPerformanceCounter(&g_race_start);

    printf("[1/2] Spawning & racing %d OS threads (every thread printed live)...\n", num_threads);
    fflush(stdout);

    int spawned = 0;
    for (int i = 0; i < num_threads; i++) {
        /* Throttle active concurrent threads via kernel semaphore to protect OS commit limit */
        WaitForSingleObject(g_concurrency_sem, INFINITE);

        params[i].index = i + 1;
        /* ~1.1M iterations per thread -> ~32-38 seconds total CPU race across 16 cores for 100k threads */
        params[i].iterations = 900000U + (uint32_t)((i * 7919U) % 450000U);

        DWORD tid = 0;
        HANDLE h = CreateThread(NULL, 65536, passenger_thread_worker, &params[i],
                                STACK_SIZE_PARAM_IS_A_RESERVATION, &tid);
        if (h != NULL) {
            /* Close parent handle immediately so 100k threads don't leak kernel handles; thread keeps running */
            CloseHandle(h);
            spawned++;
            printf("  Thread #%6d | PID: %-6lu | TID: %-6lu | Status: RACING\n",
                   spawned, (unsigned long)host_pid, (unsigned long)tid);
            if ((spawned & 63) == 0) {
                fflush(stdout);
            }
        } else {
            ReleaseSemaphore(g_concurrency_sem, 1, NULL);
            LONG target = InterlockedDecrement(&g_total_threads);
            if (g_threads_finished >= target) {
                SetEvent(g_all_done_event);
            }
        }
    }
    fflush(stdout);

    printf("[2/2] All %d threads spawned! Waiting for remaining threads to finish...\n", spawned);
    fflush(stdout);

    /* Wait until final worker signals completion */
    if (g_threads_finished < g_total_threads) {
        WaitForSingleObject(g_all_done_event, INFINITE);
    }

    LARGE_INTEGER race_end;
    QueryPerformanceCounter(&race_end);
    double wall_ms = (double)(race_end.QuadPart - g_race_start.QuadPart) * 1000.0 / (double)g_freq.QuadPart;

    /* Collect actual Windows OS CPU & memory stats */
    FILETIME ft_create, ft_exit, ft_kernel, ft_user;
    GetProcessTimes(GetCurrentProcess(), &ft_create, &ft_exit, &ft_kernel, &ft_user);
    double kernel_ms = filetime_to_ms(ft_kernel);
    double user_ms = filetime_to_ms(ft_user);

    PROCESS_MEMORY_COUNTERS pmc;
    SIZE_T peak_ram_kb = 0;
    if (GetProcessMemoryInfo(GetCurrentProcess(), &pmc, sizeof(pmc))) {
        peak_ram_kb = pmc.PeakWorkingSetSize / 1024;
    }

    CloseHandle(g_concurrency_sem);
    CloseHandle(g_all_done_event);
    DeleteCriticalSection(&g_seat_cs);
    free(params);

    /* Final Summary */
    printf("\n======================================================================\n");
    printf("  CONFIRMED SEAT WINNERS (%ld out of %d competing threads)\n",
           g_winner_count, spawned);
    printf("======================================================================\n");
    printf("  Seat |  Req #   |   PID   |   Thread ID (TID)  | Passenger       | Time\n");
    printf("  -----+----------+---------+--------------------+-----------------+-----------\n");
    for (LONG i = 0; i < g_winner_count; i++) {
        printf("  #%-3d | %-8d | %-7lu | %-18lu | %-15s | %.1f ms\n",
               g_winners[i].seat_no,
               g_winners[i].req_index,
               (unsigned long)g_winners[i].os_pid,
               (unsigned long)g_winners[i].os_tid,
               g_winners[i].pax_name,
               g_winners[i].finish_ms);
    }
    printf("======================================================================\n");
    printf("  Threads Spawned : %d | Winners: %ld | Waitlisted: %ld | Overbooked: 0\n",
           spawned, g_winner_count, g_waitlisted_count);
    printf("  Wall Time       : %.1f ms (%.2f sec) | CPU User+Kernel: %.1f ms (%.1fx core load)\n",
           wall_ms, wall_ms / 1000.0, user_ms + kernel_ms, (user_ms + kernel_ms) / (wall_ms > 0 ? wall_ms : 1.0));
    printf("  Peak OS RAM     : %zu KB (~%.1f MB)\n", peak_ram_kb, (double)peak_ram_kb / 1024.0);
    printf("======================================================================\n");
    fflush(stdout);

    return 0;
}
