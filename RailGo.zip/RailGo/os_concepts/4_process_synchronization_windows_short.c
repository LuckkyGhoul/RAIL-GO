#include "os_common.h"

#define MAX_THREADS 32

static int seats, confirmed, waitlisted;
static int seat_no[MAX_THREADS];
static bool booked[MAX_THREADS], duplicate[MAX_THREADS];
static CRITICAL_SECTION lock;
static HANDLE threads[MAX_THREADS];

typedef struct {
    int id;
    bool sync;
} ThreadArg;

static DWORD WINAPI book_seat(LPVOID param) {
    ThreadArg *arg = (ThreadArg *)param;
    int id = arg->id;

    if (arg->sync)
        EnterCriticalSection(&lock);

    int available = seats;

    if (!arg->sync)
        sleep_ms(15);

    if (available > 0) {
        seat_no[id] = available;
        seats = available - 1;
        confirmed++;
        booked[id] = true;
        printf("Thread %d: BOOKED seat %d\n", id + 1, seat_no[id]);
    } else {
        seat_no[id] = -1;
        waitlisted++;
        booked[id] = false;
        printf("Thread %d: WAITLISTED\n", id + 1);
    }

    if (arg->sync)
        LeaveCriticalSection(&lock);

    return 0;
}

static void run_test(int initial_seats, int n, bool sync) {
    ThreadArg args[MAX_THREADS];
    int duplicate_pairs = 0;

    seats = initial_seats;
    confirmed = waitlisted = 0;

    if (sync)
        InitializeCriticalSection(&lock);

    for (int i = 0; i < n; i++) {
        booked[i] = duplicate[i] = false;
        seat_no[i] = -1;
        args[i].id = i;
        args[i].sync = sync;

        threads[i] = CreateThread(NULL, 0, book_seat, &args[i], 0, NULL);
        if (threads[i] == NULL) {
            printf("Failed to create thread %d\n", i + 1);
            n = i;
            break;
        }
    }

    WaitForMultipleObjects(n, threads, TRUE, INFINITE);
    for (int i = 0; i < n; i++)
        CloseHandle(threads[i]);

    if (sync)
        DeleteCriticalSection(&lock);

    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++)
            if (booked[i] && booked[j] && seat_no[i] == seat_no[j]) {
                duplicate[i] = duplicate[j] = true;
                duplicate_pairs++;
            }

    printf("\n--- %s ---\n", sync ? "WITH MUTEX/CRITICAL SECTION" : "WITHOUT SYNCHRONIZATION");
    printf("Initial seats: %d | Threads: %d\n", initial_seats, n);
    printf("Confirmed: %d | Waitlisted: %d | Seats left: %d\n",
           confirmed, waitlisted, seats);
    printf("Duplicate seat pairs: %d\n", duplicate_pairs);

    for (int i = 0; i < n; i++)
        printf("Thread %2d | %-9s | Seat: %d | %s\n",
               i + 1, booked[i] ? "CONFIRMED" : "WAITLIST",
               seat_no[i], duplicate[i] ? "DUPLICATE!" : "OK");
}

int main(void) {
    int choice, initial_seats, n;

    while (1) {
        print_header("PROCESS SYNCHRONIZATION",
                     "Race Condition vs Critical Section");
        printf("1. Without synchronization\n");
        printf("2. With synchronization\n");
        printf("3. Compare both\n");
        printf("0. Exit\n");

        choice = read_int_bounded("Choice", 0, 3, 3);
        if (choice == 0)
            break;

        initial_seats = read_int_bounded("Available seats", 1, 20, 3);
        n = read_int_bounded("Concurrent booking threads", 2, MAX_THREADS, 8);

        if (choice == 1)
            run_test(initial_seats, n, false);
        else if (choice == 2)
            run_test(initial_seats, n, true);
        else {
            printf("\n--- PART 1: WITHOUT SYNCHRONIZATION ---\n");
            run_test(initial_seats, n, false);
            printf("\nPress ENTER for synchronized test...");
            getchar();
            getchar();
            printf("\n--- PART 2: WITH SYNCHRONIZATION ---\n");
            run_test(initial_seats, n, true);
        }
        press_enter_to_continue();
    }
    return 0;
}
