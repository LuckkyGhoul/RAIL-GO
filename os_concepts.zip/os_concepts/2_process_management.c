#include "os_common.h"

#define MAX_PROCESSES 32

typedef enum {
    STATE_NEW,        /* Process created, PCB allocated in kernel memory */
    STATE_READY,      /* In Ready Queue awaiting CPU Dispatcher */
    STATE_RUNNING,    /* Currently executing on CPU */
    STATE_WAITING,    /* Blocked waiting for I/O (Payment Gateway / DB Disk) */
    STATE_TERMINATED  /* Execution finished, exit code reported */
} ProcessState;

typedef struct {
    int pid;
    char pax_name[32];
    char pnr[12];
    ProcessState state;
    int priority;
    int io_burst_ms;
    int cpu_burst_ms;
    int allocated_berth;
    char exit_status[32];
} PCB; /* Process Control Block */

const char *get_state_str(ProcessState s) {
    switch (s) {
        case STATE_NEW:        return "NEW";
        case STATE_READY:      return "READY";
        case STATE_RUNNING:    return "RUNNING";
        case STATE_WAITING:    return "WAITING (I/O)";
        case STATE_TERMINATED: return "TERMINATED";
        default:               return "UNKNOWN";
    }
}

void print_pcb_table(PCB proc[], int n, const char *step_description) {
    printf("\n  >>> [PROCESS TABLE SNAPSHOT]: %s <<<\n", step_description);
    printf("  +-------+----------------+-----------+----------------+----------+-----------------------+\n");
    printf("  |  PID  | Passenger Name |    PNR    | Current State  | Priority | Booking Result        |\n");
    printf("  +-------+----------------+-----------+----------------+----------+-----------------------+\n");
    for (int i = 0; i < n; i++) {
        char berth_str[32];
        if (proc[i].allocated_berth > 0) {
            snprintf(berth_str, sizeof(berth_str), "CNF (Berth #%d)", proc[i].allocated_berth);
        } else if (proc[i].state == STATE_TERMINATED) {
            snprintf(berth_str, sizeof(berth_str), "%s", proc[i].exit_status);
        } else {
            snprintf(berth_str, sizeof(berth_str), "Pending...");
        }

        printf("  | P%-4d | %-14s | %-9s | %-14s | %-8d | %-21s |\n",
               proc[i].pid, proc[i].pax_name, proc[i].pnr,
               get_state_str(proc[i].state), proc[i].priority, berth_str);
    }
    printf("  +-------+----------------+-----------+----------------+----------+-----------------------+\n\n");
}

int main(void) {
    srand((unsigned int)time(NULL));

    print_header("PROCESS MANAGEMENT & PCB LIFECYCLE",
                 "5-State Process Model (NEW -> READY -> RUNNING -> WAITING -> TERMINATED)");

    int total_seats = read_int_bounded("Available train berths", 1, 50, 3);
    int num_pax     = read_int_bounded("Total booking processes", 1, MAX_PROCESSES, 5);

    PCB proc[MAX_PROCESSES];
    int base_pid = 2001;

    printf("\n  [1. PROCESS CREATION & READY QUEUE ADMISSION]\n");
    for (int i = 0; i < num_pax; i++) {
        proc[i].pid = base_pid + i;
        snprintf(proc[i].pax_name, sizeof(proc[i].pax_name), "Passenger%d", i + 1);
        snprintf(proc[i].pnr, sizeof(proc[i].pnr), "%lld", 8000000000LL + rand() % 999999999L);
        proc[i].state = STATE_READY;
        proc[i].priority = (rand() % 3) + 1;
        proc[i].cpu_burst_ms = 80 + (rand() % 40);
        proc[i].io_burst_ms = 100 + (rand() % 60);
        proc[i].allocated_berth = -1;
        strncpy(proc[i].exit_status, "INITIALIZING", sizeof(proc[i].exit_status));

        printf("  -> [sys_fork] PID %d (%-12s) | PNR: %s | State: NEW -> READY\n",
               proc[i].pid, proc[i].pax_name, proc[i].pnr);
        sleep_ms(40);
    }

    /* CPU Dispatch & Execution */
    int available_berths = total_seats;
    int next_berth = 1;

    printf("\n  [2. CPU DISPATCH, I/O WAITING & CONTEXT SWITCHING]\n");
    for (int i = 0; i < num_pax; i++) {
        /* Transition log: READY -> RUNNING -> WAITING -> READY -> TERMINATED */
        proc[i].state = STATE_RUNNING;
        sleep_ms(proc[i].cpu_burst_ms / 2);

        proc[i].state = STATE_WAITING;
        sleep_ms(proc[i].io_burst_ms / 2);

        proc[i].state = STATE_RUNNING;

        if (available_berths > 0) {
            proc[i].allocated_berth = next_berth++;
            available_berths--;
            snprintf(proc[i].exit_status, sizeof(proc[i].exit_status), "CNF (Berth #%d)", proc[i].allocated_berth);
        } else {
            proc[i].allocated_berth = -1;
            snprintf(proc[i].exit_status, sizeof(proc[i].exit_status), "WAITLIST (Refund)");
        }

        proc[i].state = STATE_TERMINATED;

        printf("  -> [Context Switch] PID %d (%-12s): RUNNING -> WAITING (I/O) -> %s\n",
               proc[i].pid, proc[i].pax_name, proc[i].exit_status);
        sleep_ms(100);
    }

    /* Final Summary Table */
    print_pcb_table(proc, num_pax, "FINAL PROCESS EXECUTION SUMMARY");

    printf("  [OPERATING SYSTEM SUMMARY]\n");
    printf("  -------------------------------------------------------------------------\n");
    printf("  * Total Processes Handled   : %d\n", num_pax);
    printf("  * Total Berths Allocated    : %d\n", total_seats - available_berths);
    printf("  * Waitlisted / Refunded     : %d\n", num_pax - (total_seats - available_berths));
    printf("  * Context Switches Performed: %d\n", num_pax * 2);
    printf("  * All PCBs successfully reclaimed from kernel memory.\n");
    printf("  =========================================================================\n");

    press_enter_to_continue();
    return 0;
}
